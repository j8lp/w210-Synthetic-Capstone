package io.swagger.api.factories;

import io.swagger.api.NextmoveApiService;
import io.swagger.api.impl.NextmoveApiServiceImpl;

@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2017-04-15T00:29:22.981Z")
public class NextmoveApiServiceFactory {
    private final static NextmoveApiService service = new NextmoveApiServiceImpl();

    public static NextmoveApiService getNextmoveApi() {
        return service;
    }
}
