package io.swagger.api.impl;

import io.swagger.api.*;
import io.swagger.model.*;

import io.swagger.model.BGAGameData;
import io.swagger.model.BGAMove;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.swagger.api.NotFoundException;

import java.io.InputStream;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;

import dk.ilios.hivemind.Constants;
import dk.ilios.hivemind.ai.HiveAI;
import dk.ilios.hivemind.ai.KillerHeuristicTranspostionTableIDDFSAlphaBetaMiniMaxAI;
import dk.ilios.hivemind.ai.heuristics.SimpleHeuristicV3;
import dk.ilios.hivemind.debug.HiveAsciiPrettyPrinter;
import dk.ilios.hivemind.game.Game;
import dk.ilios.hivemind.game.GameCommand;
import dk.ilios.hivemind.model.Board;
import dk.ilios.hivemind.model.BugType;
import dk.ilios.hivemind.model.Hex;
import dk.ilios.hivemind.model.Player;
import dk.ilios.hivemind.model.Player.PlayerType;
import dk.ilios.hivemind.model.Token;
import dk.ilios.hivemind.model.rules.Bug;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.validation.constraints.*;
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2017-04-15T00:29:22.981Z")
public class NextmoveApiServiceImpl extends NextmoveApiService {
    @Override
    public Response nextmove(BGAGameData gameUiGameData, SecurityContext securityContext) throws NotFoundException {
        // do some magic!
        Map<String,Player> playerMap = new HashMap<String, Player>();
    	Player white = new Player("White", Player.PlayerType.WHITE);

        Player black = new Player("Black", Player.PlayerType.BLACK);
        Game game = new Game();
        game.addPlayers(white, black);
        Board board = game.getBoard();
        //Sort token list by height.  Lowest pieces go first.
        List<BGAToken> sorted = gameUiGameData.getTokens();
        sorted.sort(Comparator.comparing(BGAToken::getTokenH));
        for(BGAToken bgaToken: sorted){
        	char colorChar = bgaToken.getSym().charAt(0);
        	BugType bugType = Constants.BGABugMap.get(bgaToken.getTypeToken());
        	Token token = null;
        	if (colorChar == 'w'){
        		playerMap.put(bgaToken.getPlayerNo(), white);
        		token = new Token(white,bugType);
        	} else if (colorChar == 'b'){
        		playerMap.put(bgaToken.getPlayerNo(),black);
        		token = new Token(black,bugType);
        	}
    		token.setId(Integer.toString(bgaToken.getTokenId()));
        	//Add token to supply first to register queen bee
    		token.getPlayer().addToSupply(token,true);
        	if(bgaToken.getTokenH() >= 0){
        	//Add token to board if h >= 0
        	board.addToken(token, bgaToken.getTokenX() * -1, bgaToken.getTokenY());
        	}
        	
        }
        String activePlayerId = gameUiGameData.getGamestate().getActivePlayer();
        game.setActivePlayer(playerMap.get(activePlayerId));
        HiveAsciiPrettyPrinter printer = new HiveAsciiPrettyPrinter();
        printer.print(board);

        HiveAI hiveAI = new KillerHeuristicTranspostionTableIDDFSAlphaBetaMiniMaxAI("KillerMove-TT-IDDFS-AB", new SimpleHeuristicV3(), 3, 180000);
        GameCommand move = hiveAI.nextMove(game, board);
        BGAMove bgaMove = new BGAMove();
        bgaMove.setMove(!(move.getFromQ() == Hex.SUPPLY));
        bgaMove.setX(move.getToQ() * -1);
        bgaMove.setY(move.getToR());
        bgaMove.setToken(Integer.valueOf(move.getToken().getId()));
        return Response.ok(bgaMove).build();
    }
    
    
   
}
