package dk.ilios.hivemind;

import java.util.Collections;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import com.google.common.collect.ImmutableBiMap;

import dk.ilios.hivemind.model.BugType;

public class Constants {
    public static final boolean DEBUG = true;
public static final BiMap<Integer,BugType> BGABugMap = 
new ImmutableBiMap.Builder<Integer, BugType>()
	.put(0, BugType.SOLDIER_ANT)
	.put(1, BugType.BEETLE)
	.put(2, BugType.GRASSHOPPER)
	.put(3, BugType.LADY_BUG)
	.put(4, BugType.MOSQUITO)
	.put(5, BugType.QUEEN_BEE)
	.put(6, BugType.SPIDER)
	.put(7, BugType.PILL_BUG)
	.build();
}
