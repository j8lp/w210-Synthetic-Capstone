package io.swagger.api;

import io.swagger.model.*;
import io.swagger.api.NextmoveApiService;
import io.swagger.api.factories.NextmoveApiServiceFactory;

import io.swagger.annotations.ApiParam;
import io.swagger.jaxrs.*;

import io.swagger.model.BGAGameData;
import io.swagger.model.BGAMove;

import java.util.List;
import io.swagger.api.NotFoundException;

import java.io.InputStream;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.*;
import javax.validation.constraints.*;

@Path("/nextmove")


@io.swagger.annotations.Api(description = "the nextmove API")
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaJerseyServerCodegen", date = "2017-04-15T00:29:22.981Z")
public class NextmoveApi  {
   private final NextmoveApiService delegate = NextmoveApiServiceFactory.getNextmoveApi();

    @POST
    
    @Consumes({ "application/json" })
    @Produces({ "application/json"})
    @io.swagger.annotations.ApiOperation(value = "Takes in game state and recommends next move", notes = "", response = BGAMove.class, authorizations = {
        @io.swagger.annotations.Authorization(value = "api_key")
    }, tags={  })
    @io.swagger.annotations.ApiResponses(value = { 
        @io.swagger.annotations.ApiResponse(code = 200, message = "Recommended move", response = BGAMove.class),
        
        @io.swagger.annotations.ApiResponse(code = 405, message = "Invalid input", response = BGAMove.class) })
    public Response nextmove(@ApiParam(value = "game data" ,required=true) BGAGameData gameUiGameData
,@Context SecurityContext securityContext)
    throws NotFoundException {
        return delegate.nextmove(gameUiGameData,securityContext);
    }
}
