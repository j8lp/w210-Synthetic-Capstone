package common;

import java.net.CookiePolicy;
import java.net.HttpCookie;
import java.net.URI;

public class CookiePolicyIgnoreDeleted implements CookiePolicy {

	@Override
	public boolean shouldAccept(URI uri, HttpCookie cookie) {
		if (cookie.getValue().equalsIgnoreCase("deleted")){
			return false;
		}
		return CookiePolicy.ACCEPT_ORIGINAL_SERVER.shouldAccept(uri, cookie);
	}

}
