package common;

public class BGAConstants {
public static final String BGA_HOST = "en.boardgamearena.com";
public static final String BGA_SOCKET = "https://c.boardgamearena.net";
}
