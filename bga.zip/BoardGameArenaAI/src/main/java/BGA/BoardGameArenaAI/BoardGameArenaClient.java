package BGA.BoardGameArenaAI;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.HttpCookie;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.http.client.utils.URIBuilder;
import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import common.BGAConstants;
import common.CookiePolicyIgnoreDeleted;
import io.socket.client.Ack;
import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;

public class BoardGameArenaClient {
	private Socket socket;
	private HttpServletResponse response;
	private BoardGameArenaHTTPConnection httpClient;
	public BoardGameArenaClient(String user, String pass,HttpServletResponse response){
		httpClient = new BoardGameArenaHTTPConnection(user,pass);
		try {
			initSocketConnection();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void initSocketConnection() throws Exception{		
			httpClient.login();
			String cred = httpClient.getCredentials();
			IO.Options opts = new IO.Options();
			opts.query = "user=" + httpClient.getPlayerID();
			opts.query += "&name=" + httpClient.getUser();
			opts.query += "&credentials=" + cred;
			socket = IO.socket(BGAConstants.BGA_SOCKET,opts);
			
		socket.on("connect", new Emitter.Listener() {

		  @Override
		  public void call(Object... args) {
		    socket.emit("join","/player/p" + httpClient.getPlayerID());
		  }

		}).on("bgamsg", new Emitter.Listener() {

		  @Override
		  public void call(Object... args) {
				try {
					JSONArray j = new JSONObject(args).getJSONArray("data");
					
					response.getWriter().append("got message");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			  
		  }

		}).on(Socket.EVENT_DISCONNECT, new Emitter.Listener() {

		  @Override
		  public void call(Object... args) {
		  }

		});
		socket.connect();
	
    }
}


