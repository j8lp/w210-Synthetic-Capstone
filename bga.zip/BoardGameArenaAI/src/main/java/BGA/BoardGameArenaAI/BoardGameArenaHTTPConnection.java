package BGA.BoardGameArenaAI;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.HttpCookie;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.client.utils.URIBuilder;
import org.json.JSONObject;
import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import common.BGAConstants;
import common.CookiePolicyIgnoreDeleted;
import io.socket.client.Ack;
import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;

public class BoardGameArenaHTTPConnection {
	private URIBuilder urlBuilder;
	private Socket socket;
	private CookieManager cookieManager;
	public String user, playerID;
	private String pass;
	private HttpServletResponse response;
	public BoardGameArenaHTTPConnection(String user, String pass){
		cookieManager = new CookieManager();
		CookieHandler.setDefault(cookieManager);
		cookieManager.setCookiePolicy(new CookiePolicyIgnoreDeleted());
		this.user = user;
		this.pass = pass;
		this.response = response;
		disableCertificates();
		this.urlBuilder = new URIBuilder().setHost(BGAConstants.BGA_HOST).setScheme("https").setPort(443);
	}
	
	public String getUser(){
		return this.user;
	}
	public String getPass(){
		return this.pass;
	}
	public String getPlayerID(){
		return this.playerID;
	}
	
	public static void disableCertificates() {
	    TrustManager[] trustAllCerts = new TrustManager[]{
	        new X509TrustManager() {

	            @Override
	            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
	                return null;
	            }

	            @Override
	            public void checkClientTrusted(
	                    java.security.cert.X509Certificate[] certs, String authType) {
	            }

	            @Override
	            public void checkServerTrusted(
	                    java.security.cert.X509Certificate[] certs, String authType) {
	            }
	        }
	    };

	    // Install the all-trusting trust manager
	    try {
	        SSLContext sc = SSLContext.getInstance("SSL");
	        sc.init(null, trustAllCerts, new java.security.SecureRandom());
	        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
	    } catch (Exception e) {
	    }
	}
	

	
	public void login() throws Exception{

		urlBuilder.clearParameters();
		urlBuilder.setPath("/account/account/login.html");
		urlBuilder.addParameter("email", this.user);
		urlBuilder.addParameter("password", this.pass);
		URL url = urlBuilder.build().toURL();
		HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
		conn.setRequestMethod("POST");
			conn.setRequestProperty("Accept", "application/json");
			
conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
			if (conn.getResponseCode() != 200) {
				System.out.println(conn.getErrorStream());
				throw new RuntimeException("Failed : HTTP error code : "
						+ conn.getResponseCode() + " - "
						+ conn.getResponseMessage());
			}
			JSONObject j = getJSONResponse(conn);
			conn.disconnect();
			this.playerID  = j.getJSONObject("data").getJSONObject("infos").getString("new_id");


		
	}
	
	public String getCredentials() throws IOException, URISyntaxException{
		urlBuilder.clearParameters();
		urlBuilder.setPath("");
		URL url = urlBuilder.build().toURL();
		List<HttpCookie> cookies = cookieManager.getCookieStore().get(urlBuilder.build());
		
		Connection conn = Jsoup.connect(url.toString());
		for(HttpCookie cookie: cookies){
			conn = conn.cookie(cookie.getName(),cookie.getValue());
		}
		Document document = conn.get();
String contentScript = document.select("#overall-content > script").html();
		Pattern pattern = Pattern.compile("mainsite\\.create\\([^,]+,\\s?\"([^,]+)\",",Pattern.MULTILINE);					
				
				Matcher matcher = pattern.matcher(contentScript);
				if(matcher.find()){
				return matcher.group(1);
				} else{				
				throw new RuntimeException("Failed : No Credentials found : ");
				}
	}

	
//Make a generic get call to BGA url + path.  Pass in pairs as header params  "Key:Value,Key:Value..."
	public JSONObject getGeneric(String path, String headers) throws Exception{
	HttpsURLConnection conn = null;
		urlBuilder.clearParameters();
try{
	urlBuilder.setPath(path);
	String[] pairs = headers.split(",");
	for (int i=0;i<pairs.length;i++) {
	    String pair = pairs[i];
	    String[] keyValue = pair.split(":");
	    urlBuilder.addParameter(keyValue[0], keyValue[1]);
	}
	URL url = urlBuilder.build().toURL();
	conn = (HttpsURLConnection) url.openConnection();
	conn.setRequestMethod("POST");
	conn.setRequestProperty("Accept", "application/json");
		if (conn.getResponseCode() != 200) {
			System.out.println(conn.getErrorStream());
			throw new RuntimeException("Failed : HTTP error code : "
					+ conn.getResponseCode() + " - "
					+ conn.getResponseMessage());
		}
		JSONObject j = getJSONResponse(conn);
		return getJSONResponse(conn);
	} catch(Exception e){
		if (conn != null){
			conn.disconnect();
			};
	throw e;	
	}
}
	
	public JSONObject getJSONResponse(HttpsURLConnection conn) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		String inputLine ="";
		JSONObject j = null;
		while ((inputLine = br.readLine()) != null){
			try{
				j = new JSONObject(inputLine);
				break;
			}
			catch(Exception e){
				continue;
			}
		}
		br.close();
		return j;
	
}
}
